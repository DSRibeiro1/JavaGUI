
public class App {

	public static void main(String[] args) throws Exception {
		
        TelaInicial telaInicial = new TelaInicial();
        telaInicial.telaCadastro();
    }
}



		

	